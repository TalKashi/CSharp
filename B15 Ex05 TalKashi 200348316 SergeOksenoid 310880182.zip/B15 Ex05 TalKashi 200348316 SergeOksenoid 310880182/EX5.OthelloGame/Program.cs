﻿namespace EX5.Othello
{
    public class Program
    {
        public static void Main()
        {
            new OthelloGame().StartGame();
        }
    }
}
